// -*- mode: c; -*-
attribute highp vec3 a_position;
uniform highp mat4 mvp;
void main(void)
{
	gl_Position = mvp * vec4(a_position, 1);
}
