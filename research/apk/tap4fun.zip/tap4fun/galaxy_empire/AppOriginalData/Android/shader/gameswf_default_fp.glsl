// -*- mode: c; -*-

uniform lowp sampler2D tex0;
uniform lowp sampler2D tex0_alpha;
uniform lowp int alphachannel;

uniform lowp vec4 global_color;
varying lowp vec4 vColor;
varying mediump vec2 vTexcoord;

void main()
{
	lowp vec4 color = texture2D(tex0, vTexcoord);
	lowp vec4 colorAlpha;
	if(alphachannel == 1)
	{
		colorAlpha = texture2D(tex0_alpha, vTexcoord);
		color.a = colorAlpha.r;
	}
	color = (color + global_color) * vColor;
    gl_FragColor = color;
}
