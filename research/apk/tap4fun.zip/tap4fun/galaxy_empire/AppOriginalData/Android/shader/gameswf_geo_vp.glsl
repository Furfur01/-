// -*- mode: c; -*-
attribute highp vec2 position;
uniform highp mat4 mvp;

void main(void)
{
	gl_Position = mvp * vec4(position, 0, 1);
}
