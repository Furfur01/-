// -*- mode: c; -*-

attribute highp 	vec3 a_position;
attribute mediump 	vec2 a_texcoord;
attribute lowp 		vec4 a_color;

varying mediump vec2 vTexcoord;
varying lowp 	vec4 vColor;
uniform highp mat4 mvp;

void main(void)
{
	gl_Position = mvp * vec4(a_position, 1);
	vColor = a_color;
	vTexcoord = a_texcoord;
}
