// -*- mode: c; -*-

uniform sampler2D tex0;
uniform lowp sampler2D tex0_alpha;
uniform lowp int alphachannel;

varying mediump vec2 vTexcoord;
varying lowp 	vec4 vColor;
uniform mediump float gray_factor;

void main()
{
    lowp vec4 color = texture2D(tex0, vTexcoord);
	lowp vec4 colorAlpha;
	if(alphachannel == 1)
	{
		colorAlpha = texture2D(tex0_alpha, vTexcoord);
		color.a = colorAlpha.r;
	}
	color = color * vColor;
	lowp float grayColor = (color.r + color.g + color.b) * 0.33;
	color.rgb = mix(color.rgb, vec3(grayColor,grayColor,grayColor), gray_factor);	
	gl_FragColor = color;
}
